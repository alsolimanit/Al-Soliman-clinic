
import React from 'react';
import { Patient } from '../types';
import { User, Stethoscope, Calendar, Hash } from 'lucide-react';

interface DashboardProps {
  patients: Patient[];
}

const Dashboard: React.FC<DashboardProps> = ({ patients }) => {
  return (
    <div className="w-full bg-white rounded-[3rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] overflow-hidden border border-white animate-[fadeIn_0.8s_ease-out]">
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
      
      <div className="overflow-x-auto">
        <table className="w-full text-right border-collapse">
          <thead>
            <tr className="bg-[#1256c4] text-white">
              <th className="px-10 py-8 font-black text-xl border-b border-white/5">
                <div className="flex items-center gap-3">
                  <User size={26} className="text-[#3498db]" />
                  <span>إسم المريض كامل</span>
                </div>
              </th>
              <th className="px-10 py-8 font-black text-xl border-b border-white/5">
                <div className="flex items-center gap-3">
                  <Stethoscope size={26} className="text-[#3498db]" />
                  <span>إسم الطبيب المعالج</span>
                </div>
              </th>
              <th className="px-10 py-8 font-black text-xl border-b border-white/5 text-center">
                <div className="flex items-center justify-center gap-3">
                  <Calendar size={26} className="text-[#3498db]" />
                  <span>تاريخ تسجيل الحالة</span>
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {patients.length === 0 ? (
              <tr>
                <td colSpan={3} className="px-8 py-32 text-center text-slate-300 font-bold text-3xl bg-slate-50/50">
                   قاعدة البيانات فارغة حالياً
                </td>
              </tr>
            ) : (
              patients.map((patient, index) => (
                <tr 
                  key={patient.id} 
                  className={`hover:bg-blue-50/60 transition-all duration-300 group ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'}`}
                >
                  <td className="px-10 py-8">
                    <div className="flex items-center gap-5">
                      <div className="w-14 h-14 rounded-2xl bg-[#1256c4]/10 flex items-center justify-center text-[#1256c4] font-black text-2xl border-2 border-transparent group-hover:border-[#1256c4] group-hover:bg-[#1256c4] group-hover:text-white transition-all duration-300 shadow-sm">
                        {patient.fullName.charAt(0)}
                      </div>
                      <span className="font-black text-slate-800 text-2xl group-hover:text-[#1256c4] transition-colors leading-tight">
                        {patient.fullName}
                      </span>
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-slate-100 rounded-lg text-slate-400">
                        <Hash size={16} />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs text-[#3498db] font-black uppercase tracking-widest mb-0.5">الطبيب المختص</span>
                        <span className="font-black text-slate-700 text-xl group-hover:text-slate-900">
                          دكتور/ {patient.doctorName}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <div className="inline-flex flex-col items-center px-8 py-3 bg-white rounded-[1.5rem] font-black text-[#1256c4] text-lg border-2 border-[#1256c4]/10 shadow-sm group-hover:border-[#3498db] transition-all" dir="ltr">
                      {patient.registrationTime}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      <div className="bg-slate-50 px-10 py-8 border-t border-slate-100 flex justify-between items-center">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-4 h-4 rounded-full bg-green-500 animate-ping absolute opacity-75"></div>
            <div className="w-4 h-4 rounded-full bg-green-500 relative"></div>
          </div>
          <p className="text-slate-600 font-black text-xl">
            إجمالي الحالات المسجلة اليوم: <span className="text-[#1256c4] text-3xl mx-2 font-black underline decoration-[#3498db] decoration-4 underline-offset-8">{patients.length}</span>
          </p>
        </div>
        <div className="flex items-center gap-4 text-slate-400 font-black text-sm tracking-[0.2em] uppercase">
          <span className="bg-slate-200 px-3 py-1 rounded-md">Server Status</span>
          <span className="text-green-600">Online</span>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
