
import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import { Patient } from './types';

const SHEET_ID = '1f5SQE4TYFB4C4i0Qam2U5Fe8kC08My_F-En14hJ-l0A';
const DATA_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json`;
const NOTIFICATION_SOUND_URL = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newPatientAlert, setNewPatientAlert] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const lastPatientCount = useRef<number>(0);

  useEffect(() => {
    audioRef.current = new Audio(NOTIFICATION_SOUND_URL);
    audioRef.current.load();
    
    const savedLogin = localStorage.getItem('isLoggedIn');
    if (savedLogin === 'true') {
      setIsLoggedIn(true);
    }
  }, []);

  const handleLogin = () => {
    setIsLoggedIn(true);
    localStorage.setItem('isLoggedIn', 'true');
  };

  const formatGoogleDate = (cell: any): string => {
    if (!cell) return '--:--';
    if (cell.f) return cell.f;
    
    const v = cell.v;
    if (typeof v === 'string' && v.startsWith('Date(')) {
      const parts = v.match(/\d+/g);
      if (parts) {
        const [y, m, d, h, min, s] = parts.map(Number);
        const date = new Date(y, m, d, h || 0, min || 0, s || 0);
        return date.toLocaleString('ar-EG', { 
          year: 'numeric', 
          month: '2-digit', 
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
      }
    }
    return String(v || '--:--');
  };

  const fetchData = async () => {
    if (!isLoggedIn) return;
    try {
      const response = await fetch(`${DATA_URL}&cachebust=${Date.now()}`);
      const text = await response.text();
      const jsonData = JSON.parse(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1));
      
      const rows = jsonData.table.rows;

      /**
       * تصحيح الترتيب لضمان عرض الأسماء في أماكنها الصحيحة:
       * العمود A (Index 0): التاريخ
       * العمود B (Index 1): إسم المريض كامل (مثل AHMAD ALI OMAE)
       * العمود C (Index 2): إسم الطبيب المعالج (مثل دكتور/ علي الصياد)
       */
      const fetchedPatients: Patient[] = rows
        .map((row: any, index: number) => {
          const cells = row.c;
          return {
            id: `P-${index}`,
            registrationTime: formatGoogleDate(cells[0]),
            fullName: cells[1]?.v || 'غير معروف',   // تم تعيين العمود B للمريض
            doctorName: cells[2]?.v || 'غير محدد', // تم تعيين العمود C للطبيب
            status: 'Waiting'
          };
        })
        .reverse();

      if (lastPatientCount.current > 0 && fetchedPatients.length > lastPatientCount.current) {
        setNewPatientAlert(true);
        if (audioRef.current) {
          audioRef.current.currentTime = 0;
          audioRef.current.play().catch(e => console.warn("Audio blocked", e));
        }
        setTimeout(() => setNewPatientAlert(false), 7000);
      }
      
      lastPatientCount.current = fetchedPatients.length;
      setPatients(fetchedPatients);
      setLoading(false);
      setError(null);
    } catch (err) {
      console.error('Fetch Error:', err);
      setError('خطأ في الاتصال بقاعدة البيانات.');
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isLoggedIn) {
      fetchData();
      const interval = setInterval(fetchData, 10000); 
      return () => clearInterval(interval);
    }
  }, [isLoggedIn]);

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-[#f8fafc] font-['Cairo'] overflow-hidden" dir="rtl">
      {newPatientAlert && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] bg-[#1256c4] text-white px-12 py-6 rounded-[3rem] shadow-[0_25px_60px_-15px_rgba(18,86,196,0.5)] animate-bounce flex items-center gap-6 border-4 border-white">
          <div className="bg-white text-[#1256c4] w-12 h-12 rounded-full flex items-center justify-center shadow-lg">
            <span className="text-2xl">🔔</span>
          </div>
          <div className="flex flex-col">
            <span className="font-black text-2xl">تسجيل حالة جديدة!</span>
            <span className="text-sm font-bold opacity-90">مستشفى آل سليمان</span>
          </div>
        </div>
      )}

      <Sidebar />

      <main className="flex-1 flex flex-col mr-64 h-screen overflow-hidden">
        <Header />
        
        <div className="flex-1 p-10 overflow-y-auto bg-slate-50/50">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full text-[#1256c4]">
              <div className="w-24 h-24 border-[12px] border-slate-100 border-t-[#1256c4] rounded-full animate-spin mb-8"></div>
              <p className="font-black text-2xl tracking-wide">جاري مزامنة قاعدة البيانات...</p>
            </div>
          ) : error ? (
            <div className="bg-white p-16 rounded-[3.5rem] text-center shadow-2xl border border-red-50 mx-auto max-w-2xl mt-20">
              <div className="w-28 h-28 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-8 text-red-500 text-6xl shadow-inner">
                ⚠️
              </div>
              <p className="text-red-600 font-black text-2xl mb-10">{error}</p>
              <button 
                onClick={fetchData} 
                className="px-14 py-5 bg-[#1256c4] text-white rounded-[2rem] font-black text-xl shadow-2xl hover:bg-[#0e48a5] transition-all active:scale-95"
              >
                تحديث البيانات
              </button>
            </div>
          ) : (
            <div className="max-w-7xl mx-auto">
              <Dashboard patients={patients} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
